package org.example;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class FakeGoldBarTest {

        public static void main(String[] args) {
                // Base Setup for Edge Browser
                System.setProperty("webdriver.edge.driver", Config.DRIVER_PATH);
                EdgeOptions opt = new EdgeOptions();
                opt.addArguments("--remote-allow-origins=*");  // Set any necessary options here
                WebDriver driver = new EdgeDriver(opt);
                driver.manage().window().maximize();
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Config.TIMEOUT));

                // Open URL
                driver.get(Config.BASE_URL);

                int a = 0, b = 3, c = 6, x = 0;
                int length = 3;
                for (int i = 0; i < length; i++) {
                        driver.findElement(Locators.leftInput(i)).sendKeys("" + i);
                        driver.findElement(Locators.rightInput(i)).sendKeys("" + (length + i));
                }

                // Click the "Weigh" button and wait for the result
                driver.findElement(Locators.WEIGH_BUTTON).click();

                // Wait for and evaluate the first weighing result
                int weightIndex = 1;
                String equation = getWeighingResult(wait, weightIndex);
                x = evaluateWeighingResult(equation, a, b, c);  // Use the new generalized method for result comparison
                driver.findElement(Locators.RESET_BUTTON).click();

                // Conduct second weighing
                driver.findElement(Locators.leftInput(a)).sendKeys("" + x);
                driver.findElement(Locators.rightInput(a)).sendKeys("" + (x + 1));

                driver.findElement(Locators.WEIGH_BUTTON).click();

                // Wait for and evaluate the second weighing result
                equation = getWeighingResult(wait, ++weightIndex);
                x = evaluateWeighingResult(equation, x, x + 1, x + 2);  // Apply the same method for result comparison

                driver.findElement(By.id(Locators.COIN_PREFIX + x)).click();

                // Handle the alert and print the message
                Alert alert = wait.until(ExpectedConditions.alertIsPresent());
                System.out.println(alert.getText());
                alert.accept();

                // Print Results
                System.out.println("The Fake Gold Bar is :" + x + " with a weighing of: 2");

                // Close Browser
                driver.quit();
        }

        // Method to retrieve the result from the weighing
        private static String getWeighingResult(WebDriverWait wait, int weightIndex) {
                WebElement weightElement = wait.until(ExpectedConditions.visibilityOfElementLocated(Locators.weightResult(weightIndex)));
                return weightElement.getText();
        }

        // Generalized method to evaluate the weighing result
        private static int evaluateWeighingResult(String equation, int lessWeight, int moreWeight, int equalWeight) {
                if (equation.contains("<")) {
                        return lessWeight;  // If left is lighter
                } else if (equation.contains("=")) {
                        return equalWeight;   // If equal
                } else {
                        return moreWeight;   // If right is lighter
                }
        }
}
