package org.example;

import org.openqa.selenium.By;

public class Locators {

    // Dynamically retrieve left and right input elements
    public static By leftInput(int index) {
        return By.id("left_" + index);
    }

    public static By rightInput(int index) {
        return By.id("right_" + index);
    }

    // Button locators
    public static final By WEIGH_BUTTON = By.id("weigh");
    public static final By RESET_BUTTON = By.xpath("//button[text()='Reset']");

    // Dynamic locator for weighing results
    public static By weightResult(int index) {
        return By.xpath("(//div[@class='game-info']//ol//li)[" + index + "]");
    }

    // Alerts
    public static final String COIN_PREFIX = "coin_";  // Prefix for selecting a coin by its ID
}
