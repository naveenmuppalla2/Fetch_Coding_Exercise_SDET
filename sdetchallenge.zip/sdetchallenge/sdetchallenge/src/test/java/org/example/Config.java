package org.example;

public class Config {
    public static final String DRIVER_PATH = "src/test/driver/msedgedriver.exe";
    public static final String BASE_URL = "http://sdetchallenge.fetch.com";
    public static final int TIMEOUT = 15;  // Timeout in seconds
}
